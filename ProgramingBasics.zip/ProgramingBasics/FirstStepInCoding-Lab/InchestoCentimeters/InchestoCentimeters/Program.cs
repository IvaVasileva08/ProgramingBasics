﻿double inches = double.Parse(Console.ReadLine());
Console.WriteLine(inches * 2.54);