﻿int count_food_for_dog = int.Parse(Console.ReadLine());
int count_food_for_cat = int.Parse(Console.ReadLine());
Console.WriteLine($"{count_food_for_cat * 4 + count_food_for_dog * 2.50} lv.");