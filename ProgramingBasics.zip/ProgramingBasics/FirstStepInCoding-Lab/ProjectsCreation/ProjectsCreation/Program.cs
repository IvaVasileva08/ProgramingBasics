﻿string name = Console.ReadLine();
int count_project = int.Parse(Console.ReadLine());
Console.WriteLine($"The architect {name} will need {count_project * 3} hours to complete {count_project} project/s.");