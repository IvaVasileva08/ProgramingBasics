﻿string firstName = Console.ReadLine();
string finalName = Console.ReadLine();
int age = int.Parse(Console.ReadLine());
string town = Console.ReadLine();
Console.WriteLine($"You are {firstName} {finalName}, a {age}-years old person from {town}.");