﻿double kv_metri = double.Parse(Console.ReadLine());
double cena_za_dvora = kv_metri * 7.61;
double otstupka = 0.18 * cena_za_dvora;
Console.WriteLine($"The final price is: {cena_za_dvora - otstupka} lv.");
Console.WriteLine($"The discount is: {otstupka} lv.");